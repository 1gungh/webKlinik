<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <title>Praktik Dokter Muh.Abd.Waris</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Beranda.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Head.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Umum.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Reservasi.css'); ?>">
</head>
<body>
<body>
  <nav>
    <div class="nav-links">
      <a href="<?= base_url('BerandaBefore'); ?>" id="berandaLink">Beranda</a>
      <a href="<?= base_url('Jadwal'); ?>">Jadwal Dokter</a>
      <a href="<?= base_url(' Reservasi'); ?>" id="reservasiLink">Reservasi</a>
      <a href="<?= base_url('Riwayat'); ?>" id="riwayatLink">Riwayat Periksa</a>
    </div>
    <div class="nav-buttons">
      <a href="<?= base_url('auth/login'); ?>" class="btn-login" id="loginBtn">Login</a>
      <a href="<?= base_url('auth/daftar'); ?>" class="btn-daftar" id="daftarBtn">Daftar Sekarang</a>
      <button class="btn-logout" id="logoutBtn" style="display: none;">Logout</button>
    </div>
  </nav>
</body>
</html>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Praktik Dokter Muh.Abd.Waris</title> 
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Beranda.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Head.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Umum.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Reservasi.css'); ?>">
  <style>

    </style>
  
         <footer>
    <p>&copy; <span id="currentYear"></span> Praktik Dokter Muh.Abd.Waris. All rights reserved.</p>
    <p>Alamat: Jl. Bromo center No.2, Krajan II, Kalisat, Kec. Kalisat, Kabupaten Jember, Jawa Timur 68193</p>
    <p>Telepon: (0331) 7845872</p>
  </footer>

  
</head>
</html>

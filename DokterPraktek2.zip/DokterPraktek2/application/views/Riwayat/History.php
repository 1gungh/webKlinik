<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Riwayat Pemeriksaan</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Beranda.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Head.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Umum.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Reservasi.css'); ?>">
</head>

<body>
  <!-- riwayat.html -->
<section id="riwayat">
  <h2>Riwayat Pemeriksaan</h2>
  <table id="tabelRiwayat">
    <thead>
      <tr>
        <th>Nama</th>
        <th>Dokter</th>
        <th>Tanggal</th>
      </tr>
    </thead>
    <tbody>
      <!-- Riwayat akan dimuat di sini -->
    </tbody>
  </table>
</section>
</body>
</html>
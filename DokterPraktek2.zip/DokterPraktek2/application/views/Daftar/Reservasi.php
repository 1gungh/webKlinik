<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Praktik Dokter Muh.Abd.Waris</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Beranda.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Head.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Umum.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Reservasi.css'); ?>">
</head>
<body>
<section id="reservasi-form-section">
  <h2>Formulir Reservasi</h2>
  <form id="reservasi-form">
    <label for="nama">Nama Lengkap:</label>
    <input type="text" id="nama" name="nama" required>

    <label for="gejala">Gejala Awal:</label>
    <input type="text" id="gejala" name="gejala" required>

    <label for="keluhan">Keluhan Anda:</label>
    <textarea id="keluhan" name="keluhan" rows="4" required placeholder="Jelaskan keluhan Anda"></textarea>

    <button type="submit">Buat Reservasi</button>
  </form>
</section>

</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/auth.css') ?>">
</head>
<body>
    <main class="auth-page">
        <div class="auth-content">
            <h1>Login</h1>
            <?php if ($this->session->flashdata('error')): ?>
                <p style="color:red"><?= $this->session->flashdata('error') ?></p>
            <?php endif; ?>
            <form action="<?= base_url('auth/login_process') ?>" method="post">
                <label for="telepon">Nomor Telepon</label>
                <input type="text" name="telepon" id="telepon" required>

                <label for="password">Password</label>
                <input type="password" name="password" id="password" required>

                <button type="submit">Login</button>
            </form>
            <p>Belum punya akun? <a href="<?= base_url('auth/daftar') ?>">Daftar di sini</a></p>
        </div>
    </main>
</body>
</html>

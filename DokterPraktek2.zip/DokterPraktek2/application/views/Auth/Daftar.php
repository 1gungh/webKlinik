<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daftar</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/auth.css') ?>">
</head>
<body>
    <main class="auth-page">
        <div class="auth-content">
            <h1>Daftar</h1>
            <?php if ($this->session->flashdata('success')): ?>
                <p style="color:green"><?= $this->session->flashdata('success') ?></p>
            <?php endif; ?>
            <form action="<?= base_url('auth/register_process') ?>" method="post">
                <label for="nama">Nama Lengkap</label>
                <input type="text" name="nama" id="nama" required>

                <label for="kelamin">Jenis Kelamin</label>
                <select name="kelamin" id="kelamin" required>

                <option value="" disabled selected>-- Pilih Jenis Kelamin --</option>
                <option value="Laki-laki">Laki-laki</option>
                <option value="Perempuan">Perempuan</option>
                </select>

                <label for="tanggalLahir">Tanggal Lahir</label>
                <input type="date" name="tanggalLahir" id="tanggalLahir" required>

                <label for="alamat">Alamat</label>
                <textarea name="alamat" id="alamat" rows="3" required></textarea>

                <label for="telepon">Nomor Telepon</label>
                <input type="tel" name="telepon" id="telepon" required pattern="[0-9]{10,15}">

                <label for="password">Password</label>
                <input type="password" name="password" id="password" required minlength="8">

                <button type="submit">Daftar</button>
            </form>
            <p>Sudah punya akun? <a href="<?= base_url('auth/login') ?>">Login di sini</a></p>
        </div>
    </main>
</body>
</html>

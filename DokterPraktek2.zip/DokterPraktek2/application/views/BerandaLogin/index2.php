<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktik Dokter Muh.Abd.Waris</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/Beranda.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/Head.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/Umum.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/Reservasi.css'); ?>">
</head>
<body>
<section id="home-logged-in" style="display: none;"> <h2>Daftar Data Pasien</h2> 
<p style="text-align:center; margin-bottom: 20px; color: #555;">Kelola data pasien Anda di sini.</p> 
<div class="table-responsive-wrapper"> <table id="patient-table"> 
    <thead> <tr>
                        <th>Nama Lengkap</th>
                        <th>Jenis Kelamin</th>
                        <th>Tanggal Lahir</th>
                        <th>Alamat</th>
                        <th>No. Telepon</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody id="patient-list-body"> </tbody>
            </table>
        </div>
        <button id="tambahPasienBtn">Tambah Pasien Baru</button> 
        <div>
            <a href="<?php echo site_url('auth/logout'); ?>" class="btn btn-danger">Logout</a>
        </div>
    </section>
</body>
</html>
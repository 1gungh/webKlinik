<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Praktik Dokter Muh.Abd.Waris</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Beranda.css');?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Head.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Umum.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Reservasi.css'); ?>">
</head>
<body>
<main id="main-content"> <section id="home-logged-out">
        <div class="hero"> <img src="https://cdn-icons-png.flaticon.com/512/3774/3774299.png" alt="Ikon Stetoskop Dokter"> 
        <h1>Selamat Datang di Praktik Dokter Muh.Abd.Waris</h1> 
        <p>Platform digital terintegrasi untuk memudahkan akses layanan kesehatan Anda kapan saja, di mana saja.</p> 
        </div>
        <div class="features"> <div class="feature-card"> <h3>Jadwal Dokter Real-time</h3>
            <p>Lihat ketersediaan jadwal dokter secara langsung dan akurat.</p>
          </div>
          <div class="feature-card"> <h3>Dokter Profesional</h3>
            <p>Dapatkan penanganan dari dokter yang berpengalaman dan terpercaya di bidangnya.</p>
          </div>
          <div class="feature-card"> <h3>Riwayat Kesehatan Digital</h3>
            <p>Akses riwayat konsultasi dan resep obat Anda dengan mudah, aman, dan terstruktur.</p>
          </div>
        </div>
    </section>
</body>
</html>
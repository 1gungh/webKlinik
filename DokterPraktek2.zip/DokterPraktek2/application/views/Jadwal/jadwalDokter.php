<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Jadwal Praktik Dokter</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Beranda.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Head.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Umum.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/Reservasi.css'); ?>">
</head>
<body>

  <div class="container">
    <h2>Jadwal Praktik Dokter</h2>
    <table>
      <thead>
        <tr>
          <th>Hari</th>
          <th>Waktu Mulai</th>
          <th>Waktu Selesai</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Senin - Jumat</td>
          <td>09:00</td>
          <td>17:00</td>
        </tr>
        <tr>
          <td>Sabtu</td>
          <td>10:00</td>
          <td>14:00</td>
        </tr>
        <tr>
          <td>Minggu</td>
          <td colspan="2">Tutup</td>
        </tr>
      </tbody>
    </table>

    <div class="note">
      Jadwal ini dapat berubah sewaktu-waktu. Harap konfirmasi saat reservasi.
    </div>
  </div>

</body>
</html>

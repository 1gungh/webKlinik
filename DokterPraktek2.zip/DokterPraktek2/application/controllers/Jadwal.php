<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jadwal extends CI_Controller {
    public function index() {
        $this->load->view('layout/header');
        $this->load->view('Jadwal/jadwalDokter'); // folder + file view
        $this->load->view('layout/footer');
    }
}

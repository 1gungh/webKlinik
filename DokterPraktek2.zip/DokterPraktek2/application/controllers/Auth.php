<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Auth_models');
        $this->load->library('session');
        $this->load->helper('url');
        
    }

    // Tampilkan halaman login
    public function login() {
        $this->load->view('layout/header');
        $this->load->view('auth/login');
        $this->load->view('layout/footer');
    }

    // Tampilkan halaman register
    public function daftar() {
        $this->load->view('layout/header');
        $this->load->view('auth/daftar');
        $this->load->view('layout/footer');
    }

    // Proses login
    public function login_process() {
        $telepon = $this->input->post('telepon');
        $password = $this->input->post('password');

        $user = $this->Auth_models->get_user_by_telepon($telepon);

        if ($user && password_verify($password, $user->password)) {
            $this->session->set_userdata([
                'user_id' => $user->id,
                'user_name' => $user->nama,
                'logged_in' => TRUE
            ]);
            
            redirect('dashboard'); // Ganti ke halaman setelah login
        } else {
            $this->session->set_flashdata('error', 'Nomor Telepon atau Password salah!');
            redirect('auth/login');
        }
    }

    // Proses register
    public function register_process() {
        $data = [
            'nama' => $this->input->post('nama'),
            'kelamin' => $this->input->post('kelamin'),
            'tanggal_lahir' => $this->input->post('tanggalLahir'),
            'alamat' => $this->input->post('alamat'),
            'telepon' => $this->input->post('telepon'),
            'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
        ];

        $this->Auth_models->insert_user($data);
        $this->session->set_flashdata('success', 'Pendaftaran berhasil! Silakan login.');
        redirect('auth/login');
    }

    // Logout
    public function logout() {
        $this->session->sess_destroy();
        redirect('auth/login');
    }
}

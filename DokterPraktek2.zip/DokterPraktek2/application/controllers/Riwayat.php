<?php
class Riwayat extends CI_Controller {
    public function index() {
        $this->load->view('layout/header');
        $this->load->view('Riwayat/History');
        $this->load->view('layout/footer');
    }
}
